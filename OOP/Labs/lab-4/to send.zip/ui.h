#pragma once

#include "repository.h"


void runUI(repository *repositoryOfBots, repositoryOperations * repositoryOfOperations);