#include "FileRepository.h"
#include <fstream>
#include <iostream>


FileRepository::FileRepository() {}

FileRepository::FileRepository(std::string InputFileName) : fileName(InputFileName)
{
	this->readDataFromFile();
}

FileRepository::~FileRepository() 
{
	this->writeDataToFile();
}

void FileRepository::setFileNameRepository(const std::string file_name)
{
	this->fileName = file_name;
	this->readDataFromFile();
}

void FileRepository::readDataFromFile()
{
	std::ifstream file_in;

	file_in.open(this->fileName);

	if (file_in.fail()) {
		// file could not be opened
		file_in.close();
	}
	else 
	{
		Entity rec;
		while (file_in >> rec)
		{
			this->add(rec);
		}
		file_in.close();
	}
}

void FileRepository::writeDataToFile()
{
	std::ofstream file_out(this->fileName);

	for (auto i : this->array)
	{
		file_out << i;
	}

	file_out.close();
}



