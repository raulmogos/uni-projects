#include "UI.h"
#include "Controller.h"

#include <iostream>
#include <sstream>
#include <string>
#include <algorithm>

// constructor + destructor

UI::UI(const Controller &controller) : controller(controller) {}

UI::~UI() {}


// menus

void UI::printMenuUser()
{
	std::cout << " menu B: \n";
	std::cout << " next \n";
 	std::cout << " list location, timesAccessed(list deck D sector X1423, 5) \n";
	std::cout << " mylist \n";
	std::cout << " exit \n";
	std::cout << " \n\n\n";
}

void UI::printMenuAdministrator()
{
	std::cout << " menu A: \n";
	std::cout << " add title, location, timeOfCreation, timesAccessed, footagePreview ";
	std::cout << " (eg. add anomaly, deck D sector X1423, 01-13-3248, 5, prev123.mp15) \n";
	std::cout << " update title, newLocation, newTimeOfCreation, newTimesAccessed, newFootagePreview ";
	std::cout << " (eg. update anomaly, deck E sector X1423, 01-14-3248, 14, prev124.mp15)\n";
	std::cout << " delete title (eg. delete anomaly) \n";
	std::cout << " list \n";
	std::cout << " exit \n";
	std::cout << " \n\n\n";
}


// helper functions

void UI::deleteWhiteSpacesBeginningAndEnd(std::string& stringToCompute)
{
	while (stringToCompute[0] == ' ')
	{
		stringToCompute.erase(stringToCompute.begin());
	}
	while (stringToCompute[stringToCompute.size()-1] == ' ')
	{
		stringToCompute.erase(stringToCompute.size()-1);
	}
}

// administrator functions

void UI::addUi()
{
	Recording rec;
	std::cin >> rec;

	try
	{
		this->controller.addRecording(rec);
	}
	catch (std::exception& error)
	{
		std::cout << error.what() << '\n';
	}
}

void UI::removeUi()
{
	std::string title;
	std::getline(std::cin, title, '\n');
	if (title == "")
		return;
	
	this->deleteWhiteSpacesBeginningAndEnd(title);

	bool response = this->controller.removeRecording(title);

	if (response == true)
		std::cout << "removed succesfully \n";
	else
		std::cout << "remove -- something went wrong\n";
}

void UI::updateUi()
{
	Recording recordingToUpdate;
	std::cin >> recordingToUpdate;

	try
	{
		this->controller.updateRecording(recordingToUpdate);
	}
	catch (std::exception& error)
	{
		std::cout << error.what() << '\n';
	}
}

void UI::listUi()
{
	for (auto i : this->controller.listOfEntities())
		std::cout << i;
}


// user functions 

void UI::nextUi()
{
	Entity v = *this->controller.nextRecording();
	std::cout << v;
}

void UI::saveUi()
{
	std::string title;
	std::getline(std::cin, title, '\n');
	if (title == "")
		return;

	this->deleteWhiteSpacesBeginningAndEnd(title);

	bool response = this->controller.saveToMyList(title);

	if (response == true)
		std::cout << "saved succesfully \n";
	else
		std::cout << "save -- something went wrong\n";
}

void UI::filterUserUi()
{
	std::string location, timesAccessed;
	std::getline(std::cin, location, ',');
	std::getline(std::cin, timesAccessed, '\n');
	// delete white spaces
	this->deleteWhiteSpacesBeginningAndEnd(location);
	this->deleteWhiteSpacesBeginningAndEnd(timesAccessed);

	//filter
	std::vector<Entity> vector = this->controller.filterRepositoryByLocationAndTimesAccessed(location, timesAccessed);

	for (auto i : vector)
		std::cout << i;
}

void UI::listUserModeUi()
{
	for (auto i : this->controller.getMyList())
		std::cout << i;
}


// run modes

void UI::runModeAdministrator()
{
	system("cls");
	this->printMenuAdministrator();

	std::string firstCommand;
	
	int sw = 0;

	while (true)
	{
		std::cout << "admin >> ";
		std::cin >> firstCommand;

		if (firstCommand == "add")
			this->addUi();
		else if (firstCommand == "update")
			this->updateUi();
		else if (firstCommand == "delete" || firstCommand == "remove")
			this->removeUi();
		else if (firstCommand == "list")
			this->listUi();
		else if (firstCommand == "mode")
		{
			sw = 1; break;
		}
		else if (firstCommand == "exit")
			return;
		else
		{
			std::cout << "invalid command! \n";
		}
	}

	if (sw == 1)
		this->runModeUser();
}

void UI::runModeUser()
{
	system("cls");
	this->printMenuUser();

	std::string firstCommand;

	int sw = 0;

	while (true)
	{
		std::cout << "user >> ";
		std::cin >> firstCommand;

		if (firstCommand == "next")
			this->nextUi();
		else if (firstCommand == "save")
			this->saveUi();
		else if (firstCommand == "list")
			this->filterUserUi();
		else if (firstCommand == "mylist")
			this->listUserModeUi();
		else if (firstCommand == "mode")
		{
			sw = 1; break;
		}
		else if (firstCommand == "exit")
			return ;
		else
		{
			std::cout << "invalid command! \n";
		}
	}

	if(sw==1)
		this->runModeAdministrator();
}


// main run

void UI::run()
{
	std::string mode;
	std::string fileLocation, command;

	while (true)
	{
		std::cout << "enter fileLocation \n"; 
		std::cout << ">> ";
		std::cin >> command;
		std::getline(std::cin,fileLocation, '\n');

		this->deleteWhiteSpacesBeginningAndEnd(fileLocation);

		std::cout <<"file Location selected: "<< fileLocation << "\n";
		
		if (command == "fileLocation")
		{
			// set the file name
			this->controller.setFileNameForRepository(fileLocation);
			break;
		}
		std::cout << "\n";
	}

	while ( true )
	{
		std::cout << "choose a mode [A/B] \n";
		std::cout << "\n MODE: ";
		std::cin >> mode;
		std::cout <<"mode "<< mode;
		if (mode == "A" || mode == "B" || mode == "a" || mode == "b")
			break;
		else if (mode == "exit")
			return;
	}

	if (mode == "A" || mode == "a")
		this->runModeAdministrator();
	else if (mode == "B" || mode == "b")
		this->runModeUser();
}