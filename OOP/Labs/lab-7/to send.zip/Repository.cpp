#pragma once

#include "Repository.h"



Repository::Repository(){}

Repository::~Repository() {}



bool Repository::add(const Entity& element)
{
	for (auto i : this->array)
		if(element==i)
			return false;
	this->array.push_back(element);
	this->iteratorForRepository = this->array.begin();
	return true;
}

bool Repository::remove(const Entity& element)
{
	for(int i=0;i<this->array.size(); i++)
		if (element == this->array[i])
		{
			this->array.erase(this->array.begin() + i);
			this->iteratorForRepository = this->array.begin();
			return true;
		}
	return false;
}

bool Repository::update(const Entity& element)
{
	for (auto & i : this->array)
		if (element == i)
		{
			i = element;
			this->iteratorForRepository = this->array.begin();
			return true;
		}
	return false;
}

int Repository::getSize() const
{
	return this->array.size();
}



std::vector<Entity>  Repository::getListOfData()
{
	std::vector<Entity> vector(this->array);
	return vector;
}

std::vector<Entity>::iterator Repository::next()
{
	std::vector<Entity>::iterator v;

	if (this->iteratorForRepository == this->array.end())
	{
		this->iteratorForRepository = this->array.begin();
		this->iteratorForRepository++;
		return this->array.begin();
	}
	else if (this->iteratorForRepository == this->array.begin())
	{
		this->iteratorForRepository = this->array.begin() + 1;
		return this->array.begin();
	}
	else if (this->iteratorForRepository != this->array.end())
		this->iteratorForRepository++;

	v = this->iteratorForRepository - 1;
	return v;
}
