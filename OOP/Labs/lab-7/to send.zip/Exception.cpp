#include "Exception.h"



Exception::Exception()
{
}


Exception::~Exception()
{
}
