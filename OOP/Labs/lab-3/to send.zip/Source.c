
#include "ui.h"

int main()
{
	// we initiate the repo
	initRepository();
	runUI();

	//system("pause");
	return 0;
}