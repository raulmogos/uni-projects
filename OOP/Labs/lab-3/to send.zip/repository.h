#pragma once

typedef struct bot
{
	char serialNumber[40];
	char state[40];
	char specialization[40];
	char energyCostToRepair[40];
}bot;

typedef struct list
{
	bot bots[1001];
	int length ;
}list;

list botRepository;

void initRepository()
{
	botRepository.length = 0;
}