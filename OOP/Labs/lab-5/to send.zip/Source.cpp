#include <iostream>
#include <crtdbg.h>
#include "Repository.h"
#include "Controller.h"
#include "UI.h"
#include "Recording.h"
#include <string>


#include <ctype.h>


int main()
{
	system("mode con:cols=170 lines=30");

	//{
	//	DynamicArray<int> da;
	//	
	//	da.add(9);
	//	da.add(3);
	//	da.add(4);
	//	da.add(-5);
	//	da.add(7);

	//	da.deleteFromPosition(3);

	//	for (int i = 0; i < da.getSize(); i++)
	//		std::cout << da[i] << '\n';	

	//	DynamicArray<int> d;
	//	d = da;
	//	for (int i = 0; i < d.getSize(); i++)
	//		std::cout << d[i] << '\n';
	//}

	/*
	Repository<Record> repo;
	Controller service{repo};
	UI ui{service};
	ui.run();
	*/


	/*{
		Repository repository{};
		Controller ctrl{ repository };

		int t[10] = { 1,5,1,7,3,9 };
		std::cout << ctrl.addRecording(t[0]);
		std::cout << ctrl.addRecording(t[1]);
		std::cout << ctrl.addRecording(t[2]);
		std::cout << ctrl.addRecording(t[3]);
		std::cout << ctrl.addRecording(t[4]);
		std::cout << ctrl.addRecording(t[5]);

		int p = 0;
		std::cout << '\n';
		std::cout << ctrl.removeRecording(t[5]);
		std::cout << ctrl.removeRecording(p);
	}  */

	{
		Repository repository{};
		Controller ctrl{ repository };
		UI ui{ ctrl };
		ui.run();
	}

	/*{

	Recording r1{ "ta", "oicshdso  siocudb", "sidcus", 9, "siucbs.lp" };

	Recording r2{ "cdidu", "s sd", "fd0 sidh", 9, "dfd.lp" };

	Recording r4{ "ta", "oicshdso  siocudb", "-", 9, "siucbs.lp" };

	Recording r9{};

	std::string tp = "  y 9 ";

	int p = isalpha(tp[4]);

	for (int i=0;i < tp.size(); i++)
		std::cout << (tp[i]) << std::endl;

	if (p==9)
		std::cout << p<<'\n';

	bool t = 0;
	if ((r1 == r4))
		t = 1;


	std::cout << t;
	}*/


	
	_CrtDumpMemoryLeaks();
	
	//system("pause");
	return 0;
}