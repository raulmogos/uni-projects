#pragma once

#include "Controller.h"


class UI
{
private:

	Controller controller;

public:

	UI( const Controller &c);
	void run();
	~UI();

private:

	void printMenuA();

	void addUi();
	void removeUi();
	void updateUi();
	void listUi();
	void exitUi();

	void runModeAdministrator();
	void runModeUser();

	void deleteWhiteSpacesFromBeginning(std::string& str);

};

