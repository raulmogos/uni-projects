#pragma once
#include "DynamicArray.h"
#include "Recording.h"

typedef Recording TElement;

class Repository
{
private: 
	
	DynamicArray<TElement> array;
	
public:
	Repository();
	~Repository();

	bool add(const TElement& element);
	bool remove(const TElement& element);
	bool update(const TElement& element);

	DynamicArray<TElement> getArr() { return this->array; }

	int getSize() const;
};
