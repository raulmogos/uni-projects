#pragma once
#include "Repository.h"
#include "DynamicArray.h"

Repository::Repository()
{
}

Repository::~Repository()
{
}

bool Repository::add(const TElement& element)
{
	for (int i=0; i<this->array.getSize(); i++)
		if(element==this->array[i])
			return false;
	this->array.add(element);
	return true;
}

bool Repository::remove(const TElement& element)
{
	for(int i=0;i<this->array.getSize(); i++)
		if (element == this->array[i])
		{
			std::cout << "yeeeeees\n";
			this->array.deleteFromPosition(i);
			return true;
		}
	return false;
}

bool Repository::update(const TElement& element)
{
	for (int i = 0;i < this->array.getSize(); i++)
		if (element == this->array[i])
		{
			this->array[i] = element;
			return true;
		}
	return false;
}

int Repository::getSize() const
{
	return this->array.getSize();
}
