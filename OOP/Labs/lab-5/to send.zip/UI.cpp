#include "UI.h"
#include <iostream>
#include <sstream>
#include "Controller.h"
#include <string>
#include <algorithm>



UI::UI(const Controller &c) : controller(c) {}

UI::~UI() {}



void UI::printMenuA()
{
	std::cout << " menu A: \n";
	std::cout << " add title, location, timeOfCreation, timesAccessed, footagePreview ";
	std::cout << " (eg. add anomaly, deck D sector X1423, 01-13-3248, 5, prev123.mp15) \n";
	std::cout << " update title, newLocation, newTimeOfCreation, newTimesAccessed, newFootagePreview ";
	std::cout << " (eg. update anomaly, deck E sector X1423, 01-14-3248, 14, prev124.mp15)\n";
	std::cout << " delete title (eg. delete anomaly) \n";
	std::cout << " list \n";
	std::cout << " exit \n";
	std::cout << " \n\n\n";
}

void UI::deleteWhiteSpacesFromBeginning(std::string& str)
{
	while (str[0] == ' ')
		for (unsigned int i = 0; i < str.size(); i++)
			str[i] = str[i+1];
	
	// erase white spaces at end
}

void UI::addUi()
{
	//LABEL:

	std::string title, location, timeOfCreation, timesAccessed, footagePreview;

	std::getline(std::cin, title, ',');
	std::getline(std::cin, location, ',');
	std::getline(std::cin, timeOfCreation, ',');
	std::getline(std::cin, timesAccessed, ',');
	std::getline(std::cin, footagePreview, '\n');

	this->deleteWhiteSpacesFromBeginning(title);
	this->deleteWhiteSpacesFromBeginning(location);
	this->deleteWhiteSpacesFromBeginning(timeOfCreation);
	this->deleteWhiteSpacesFromBeginning(timesAccessed);
	this->deleteWhiteSpacesFromBeginning(footagePreview);
/*
	std::cout << title <<'-';
	std::cout << location << '-';
	std::cout << timeOfCreation << '-';
	std::cout << timesAccessed << '-';
	std::cout << footagePreview << '-';*/
	
	std::cout << timesAccessed[0]<<std::endl;
	if (!isdigit(timesAccessed[0]))
		return;

	bool resp = this->controller.addRecording(title, location, timeOfCreation, timesAccessed, footagePreview);

	if (resp == true)
		std::cout << "added succesfully \n";
	else
		std::cout << "add -- something went wrong\n";
}

void UI::removeUi()
{
	std::string title;
	std::getline(std::cin, title, '\n');
	if (title == "")
		return;
	
	this->deleteWhiteSpacesFromBeginning(title);

	bool resp = this->controller.removeRecording(title);

	if (resp == true)
		std::cout << "removed succesfully \n";
	else
		std::cout << "remove -- something went wrong\n";
}

void UI::updateUi()
{
	std::string title, location, timeOfCreation, timesAccessed, footagePreview;

	std::getline(std::cin, title, ',');
	std::getline(std::cin, location, ',');
	std::getline(std::cin, timeOfCreation, ',');
	std::getline(std::cin, timesAccessed, ',');
	std::getline(std::cin, footagePreview, '\n');

	this->deleteWhiteSpacesFromBeginning(title);
	this->deleteWhiteSpacesFromBeginning(location);
	this->deleteWhiteSpacesFromBeginning(timeOfCreation);
	this->deleteWhiteSpacesFromBeginning(timesAccessed);
	this->deleteWhiteSpacesFromBeginning(footagePreview);

	std::cout << timesAccessed[0] << std::endl;
	if (!isdigit(timesAccessed[0]))
		return;

	bool resp = this->controller.updateRecording(title, location, timeOfCreation, timesAccessed, footagePreview);
	
	if (resp == true)
		std::cout << "updated succesfully \n";
	else
		std::cout << "update -- something went wrong\n";
}

void UI::listUi()
{
	Repository repo = this->controller.getRepo();
	for (int i = 0; i < repo.getSize(); i++)
	{
		std::cout << repo.getArr()[i].toString();
	}
}

void UI::exitUi()
{
}

void UI::runModeAdministrator()
{
	system("cls");
	this->printMenuA();

	std::string firstCommand;
	
	while (true)
	{
		std::cout << "user >> ";
		std::cin >> firstCommand;

		if (firstCommand == "add")
			this->addUi();
		else if (firstCommand == "update")
			this->updateUi();
		else if (firstCommand == "delete" || firstCommand == "remove")
			this->removeUi();
		else if (firstCommand == "list")
			this->listUi();
		else if (firstCommand == "exit")
			break;
	}

}

void UI::runModeUser()
{

}


void UI::run()
{
	std::cout << "choose a mode [A/B] \n";

	std::string mode;

	while ( true )
	{
		std::cout << "\n MODE: ";
		std::cin >> mode;
		std::cout <<"mode "<< mode;
		if(mode == "A" || mode == "B" || mode == "a" || mode == "b")
			break;
	}

	if (mode == "A" || mode == "a")
		this->runModeAdministrator();
	else if (mode == "B" || mode == "b")
		this->runModeUser();
}